#include <SPI.h>
#include <Ethernet.h>

#define BAUDRATE 115200
#define LED_Y 30
#define LED_B 34

byte mac[] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED};

EthernetServer server(80);

void sendPage(EthernetClient &client) {
  client.println(F("HTTP/1.1 200 OK"));
  client.println(F("Content-Type: text/html; charset=utf-8"));
  client.println(F("Connection: close"));
  client.println();
  client.println(F("<!DOCTYPE html><html><head><meta charset='utf-8'>"
                   "<meta name='viewport' content='width=device-width, initial-scale=1'>"
                   "<title>LED Control</title></head><body>"));
  client.println(F("<h2>Arduino Mega with W5100 Ethernet Shield</h2>"));
  client.println(F("<p><a href='/?ledY=on'>LED_Y ON</a> | <a href='/?ledY=off'>LED_Y OFF</a></p>"));
  client.println(F("<p><a href='/?ledR=on'>LED_B ON</a> | <a href='/?ledR=off'>LED_B OFF</a></p>"));
  client.println(F("</body></html>"));
}

void setup() {
  Serial.begin(BAUDRATE);

  pinMode(LED_Y, OUTPUT);
  pinMode(LED_B, OUTPUT);
  digitalWrite(LED_Y, LOW);
  digitalWrite(LED_B, LOW);

// W5100 needs CS HIGH - GPIO 10
  pinMode(10, OUTPUT);
  digitalWrite(10, HIGH);

  Serial.print(F("Starting DHCP ")); 
  while (Ethernet.begin(mac) == 0) {
    Serial.print(F("."));
    delay(250);
  }
  Serial.println(" Connected");
  delay(1000); 
  server.begin();
  Serial.print(F("Server IP adress is "));
  Serial.println(Ethernet.localIP());
}

void loop() {
  EthernetClient client = server.available();
  if (!client) return;

  // Read only the request line (first line): "GET /?... HTTP/1.1"
  String reqLine = client.readStringUntil('\r');
  client.read(); // read '\n'

  // Drain the rest of bytes
  while (client.connected()) {
    String h = client.readStringUntil('\n');
    if (h == "\r" || h.length() == 1) break; // blank line
  }

  // Example reqLine: "GET /?led1=on"
  if (reqLine.startsWith("GET ")) {
    int pathStart = 4;
    int pathEnd = reqLine.indexOf(' ', pathStart);
    String path = (pathEnd > pathStart) ? reqLine.substring(pathStart, pathEnd) : "";

    if (path.indexOf("ledY=on") >= 0)  digitalWrite(LED_Y, HIGH);
    if (path.indexOf("ledY=off") >= 0) digitalWrite(LED_Y, LOW);
    if (path.indexOf("ledB=on") >= 0)  digitalWrite(LED_B, HIGH);
    if (path.indexOf("ledB=off") >= 0) digitalWrite(LED_B, LOW);
  }

  sendPage(client);
  delay(100);
  client.stop();
}
