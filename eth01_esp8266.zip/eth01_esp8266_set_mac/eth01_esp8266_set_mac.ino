#include<ESP8266WiFi.h>
#define BAUDRATE 115200

uint8_t newMACAddress[] = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66};

void setup() {
  Serial.begin(BAUDRATE);
  Serial.print("Current ESP Board MAC Address:  ");
  Serial.println(WiFi.macAddress());

  wifi_set_macaddr(STATION_IF, &newMACAddress[0]); 
  Serial.print("New ESP8266 Board MAC Address:  ");
  Serial.println(WiFi.macAddress());
}

void loop() {
}
