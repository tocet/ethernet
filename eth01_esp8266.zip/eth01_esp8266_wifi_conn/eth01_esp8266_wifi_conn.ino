// https://arduino-esp8266.readthedocs.io/en/latest/esp8266wifi/readme.html
#include<ESP8266WiFi.h>
#define BAUDRATE 115200

const char* ssid = "";
const char* pass = "";

#define CONN_DELAY 500
long p_millis = 0;

void setup() {
 Serial.begin(BAUDRATE);
 WiFi.mode(WIFI_STA);
 WiFi.begin(ssid,pass);
 Serial.print("Connecting to "); Serial.print(ssid); 
 Serial.print("with password "); Serial.println(pass);
 Serial.print("Start connection .");
 while((WiFi.status()!=WL_CONNECTED)&&(millis()-p_millis>CONN_DELAY)) {
  Serial.print("."); 
  switch(WiFi.status()) {
    case WL_IDLE_STATUS:
      Serial.println("Wi-Fi is in process of changing between statuses");
      break;

    case WL_NO_SSID_AVAIL:
      Serial.println("Configured SSID cannot be reached");
      break;

    case WL_CONNECT_FAILED:
      Serial.println("Connection failed");
      break;

    case WL_WRONG_PASSWORD:
      Serial.println("Password is incorrect");
      break;
      
    case WL_DISCONNECTED:
      Serial.println("Module is not configured in station mode");
      break;

    default:
      Serial.println("Unknown WiFi status message");
      break;
  }
  p_millis = millis();
 }
 
 Serial.print("ESP8266 board IP "); Serial.print(WiFi.localIP());
 WiFi.setAutoReconnect(true);   // automatically reconnect to the
 WiFi.persistent(true);         // previously connected AP
 
 Serial.setDebugOutput(true);
 WiFi.printDiag(Serial);

 Serial.printf("Connection status: %d\n", WiFi.status());
 Serial.print("RRSI: ");
 Serial.println(WiFi.RSSI());
}

void loop() {
}
