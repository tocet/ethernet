// DASH 5 
#define BAUDRATE 115200
#define PIN_TEMP_SENSOR A0
#define MCP9700A_V0C 500    //output voltaga 0 degC = 500mV
#define MCP9700A_TC 10      // temp. coeff = 10mv/degC

#include <ESP8266WiFi.h>
#include <ESPAsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <ESPDash.h>

const char* ssid = "";
const char* pass = "";

AsyncWebServer server(80);
ESPDash dashboard(server);

dash::GenericCard<dash::string> card_title(dashboard,"Title");
dash::TemperatureCard card_temperature(dashboard,"Temperature","°C");
dash::ToggleButtonCard btn_led(dashboard,"LED");

double temperature;

void wifi_connect() {
 WiFi.begin(ssid,pass);
 Serial.print("Connecting network ");
 while(WiFi.status()!=WL_CONNECTED) {
  Serial.print(".");
  delay(500); }  
 Serial.println(" done");
 Serial.print("IP adres: ");
 Serial.print(WiFi.localIP());
}

void setup() {
 Serial.begin(BAUDRATE);
 wifi_connect();
 server.begin();
 delay(500);
 
 dash::string s = "Thermometer";
 card_title.setValue(s);
 dashboard.sendUpdates();

// button registration
 btn_led.onChange([](bool state) { 
  Serial.println("Button: " + String((state)?"true":"false")); 
  digitalWrite(LED_BUILTIN,!state);
  btn_led.setValue(state); 
  dashboard.sendUpdates() ; 
 });
 btn_led.setValue(false); 
 pinMode(LED_BUILTIN,OUTPUT);
 digitalWrite(LED_BUILTIN,LOW);
 }

#define MAIN_LOOP_DELAY 2000
long p_millis=0;

void loop() {
if(millis()-p_millis>MAIN_LOOP_DELAY) {
 temperature = ((analogRead(PIN_TEMP_SENSOR)/1024.0)*3300-MCP9700A_V0C)/MCP9700A_TC;      //Ta = (Vout - MCP9700A_V0C)/MCP9700A_TC
 Serial.print("Temperature[degC] = ");  Serial.println(temperature);
 card_temperature.setValue(temperature); 
 dashboard.sendUpdates();
 p_millis = millis();}
}
