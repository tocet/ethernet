//https://github.com/olikraus/u8g2/wiki
#include<Wire.h>
#include<U8g2lib.h>
#define BAUDRATE 115200

//U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);
U8G2_SSD1306_128X32_UNIVISION_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

#define ROW_1 8
#define ROW_2 18
#define COL_START 0

void setup() {
Serial.begin(BAUDRATE);

Wire.begin();
u8g2.begin();

u8g2.clearBuffer();
u8g2.setFont(u8g2_font_ncenB08_tr); // choose a suitable font
u8g2.setCursor(COL_START, ROW_1);
u8g2.print("Display test "); 
u8g2.sendBuffer();
}

long p_millis = 0;
int i=0;
String message;
#define HR_MODE_DELAY 1000 // High Resolution Mode min.120[ms]

void loop() {
if(millis() - p_millis > HR_MODE_DELAY) {
 int t_val = random(0,100);
 u8g2.clearBuffer();
 message = "Random value " + String(t_val);
 Serial.println(message + "[unit]");
 u8g2.setCursor(COL_START, ROW_2);
 u8g2.print("RV "); u8g2.print(t_val); u8g2.print("[unit]"); 
 u8g2.sendBuffer();
 p_millis = millis();
}
}
